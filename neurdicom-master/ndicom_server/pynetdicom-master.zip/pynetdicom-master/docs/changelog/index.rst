.. _release_notes:

#############
Release Notes
#############

.. toctree::
   :maxdepth: 1

   v1.5.0
   v1.4.1
   v1.4.0
   v1.3.1
   v1.3.0
   v1.2.0
   v1.1.0
   v1.0.0
