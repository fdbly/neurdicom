.. examples:

#############
Code Examples
#############



.. toctree::
   :maxdepth: 1

   basic_worklist
   display
   mpps
   qr_find
   qr_get
   qr_move
   relevant_patient
   print
   storage
   verification
