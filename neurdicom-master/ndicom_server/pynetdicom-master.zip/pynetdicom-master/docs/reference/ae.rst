.. _api_ae:

.. py:module:: pynetdicom.ae

Application Entity (:mod:`pynetdicom.ae`)
=========================================================

.. currentmodule:: pynetdicom.ae

A representation of a DICOM Application Entity and one of *pynetdicom's* two
main user classes.

.. autosummary::
   :toctree: generated/

   ApplicationEntity
