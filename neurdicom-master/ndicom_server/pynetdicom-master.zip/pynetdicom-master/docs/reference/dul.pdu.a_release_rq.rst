.. _api_dul_pdu_areleaserq:

A-RELEASE-RQ PDU
================

.. currentmodule:: pynetdicom.pdu

An A-RELEASE-RQ PDU is made of a sequence of mandatory fields.

PDU
---

.. autosummary::
   :toctree: generated/

   A_RELEASE_RQ
