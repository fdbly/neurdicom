.. _api_dul_primitives_aabort:

A-ABORT
=======

.. currentmodule:: pynetdicom.pdu_primitives

The ACSE A-ABORT service shall be used by either of the Application Entities to
cause the abnormal release of the association.

.. autosummary::
   :toctree: generated/

   A_ABORT
