.. _api_timer:

.. py:module:: pynetdicom.timer

Timer (:mod:`pynetdicom.timer`)
================================

.. currentmodule:: pynetdicom.timer

.. autosummary::
   :toctree: generated/

   Timer
