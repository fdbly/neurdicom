=========
Tutorials
=========

New to *pynetdicom*? Then these tutorials should get you up and running.

.. toctree::
   :maxdepth: 1

   installation
   create_scu
   create_scp
